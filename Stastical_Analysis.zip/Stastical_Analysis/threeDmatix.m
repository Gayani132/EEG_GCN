
% Step 1: Specify the folder containing the CSV files
folderPath = 'C:\7th semester\EE405_Final year project\New folder\Coherancecsv'; % Update with actual path
csvFiles = dir(fullfile(folderPath, '*.csv')); % Get all CSV files in the folder

fileNames = {csvFiles.name}; % Extract only file names
fileNames = sort(fileNames); % Sort alphabetically
csvFiles = csvFiles(ismember({csvFiles.name}, fileNames)); % Keep structure format

% Step 2: Initialize empty matrices for each category
AZ = []; % Connection Cell Index × Frequency Bands × Subjects
HC = [];
FTD = [];

% Step 3: Loop through each CSV file and classify into the correct category
for i = 1:length(csvFiles)
    fileName = csvFiles(i).name;
    filePath = fullfile(folderPath, fileName); % Full path to the file
    
    % Ensure we are only reading valid CSV files
    try
        data = readmatrix(filePath); % Read CSV file
    catch
        warning('Failed to read file %s. Skipping...', fileName);
        continue;
    end
    
    % Ensure data has expected dimensions (Connection Cell Index × Frequency Bands)
    if size(data, 2) ~= 5
        warning('File %s does not match the expected number of frequency bands (5). Skipping...', fileName);
        continue;
    end
    
    % Debugging: Display file name and index
    fprintf('Processing file: %s (Index: %d)\n', fileName, i);
    
    % Classify based on file index
    if i <= 36
        AZ = cat(3, AZ, data); % First 36 are AZ
    elseif i > 36 && i <= 65
        HC = cat(3, HC, data); % Next 29 are HC
    elseif i > 65 && i <= 88
        FTD = cat(3, FTD, data); % Next 23 are FTD
    else
        warning('File %s does not belong to AZ, HC, or FTD category.', fileName);
    end
end



% Step 5: Compute Mean Across Subjects
meanAZ = computeMean(AZ);
meanHC = computeMean(HC);
meanFTD = computeMean(FTD);

% Step 6: Compute Standard Error (STE) Across Subjects
steAZ = computeSTE(AZ);
steHC = computeSTE(HC);
steFTD = computeSTE(FTD);

% Step 7: Stack Mean and STE into 3D Arrays
meanData = cat(3, meanAZ, meanHC, meanFTD);
steData = cat(3, steAZ, steHC, steFTD);

% Step 8: Store the categorized data in a structure
Coherence = struct();    
Coherence.AZ = AZ; 
Coherence.HC = HC;
Coherence.FTD = FTD;
Coherence.mean = meanData;
Coherence.ste = steData;


% Step 9: Save the structure to a .mat file
save('coherenceData.mat', 'Coherence'); 

disp('MAT file saved successfully.');

% Function to compute the mean across the 3rd dimension
function meanData = computeMean(data)
    meanData = mean(data, 3, 'omitnan'); % Calculate mean across subjects
end

% Function to compute the standard error (STE) across the 3rd dimension
function steData = computeSTE(data)
    steData = std(data, 0, 3, 'omitnan') ./ sqrt(size(data, 3)); % Standard error calculation
end

% Function to extract self-connections (diagonal elements)


