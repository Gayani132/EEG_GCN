% Set the folder path where your .mat files are located
folderPath = 'C:\7th semester\EE405_Final year project\New folder\Coherance'
% List all the .mat files in the folder
matFiles = dir(fullfile(folderPath, '*.mat'));

for i = 1:numel(matFiles)
    % Load the data
    matFile = load(fullfile(folderPath, matFiles(i).name));
    TF = matFile.TF;

    % Split matrix into 5 submatrices
    submatrix1 = TF(:, :, 1:8);
    submatrix2 = TF(:, :, 9:15);
    submatrix3 = TF(:, :, 16:27);
    submatrix4 = TF(:, :, 28:60);
    submatrix5 = TF(:, :, 61:90);

    % Compute the average along the third dimension for each submatrix
    averageMatrix1 = mean(submatrix1, 3);
    averageMatrix2 = mean(submatrix2, 3);
    averageMatrix3 = mean(submatrix3, 3);
    averageMatrix4 = mean(submatrix4, 3);
    averageMatrix5 = mean(submatrix5, 3);

    % Concatenate the average matrices into a single matrix
    finalMatrix = [averageMatrix1, averageMatrix2, averageMatrix3, averageMatrix4, averageMatrix5];

    % Extract the base name of the original MAT file
    [filePath, baseName, ~] = fileparts(matFiles(i).name);

    % Define the CSV filename
    csvFile = fullfile(folderPath, [baseName, '.csv']);

    % Write the finalMatrix to the CSV file
    writematrix(finalMatrix, csvFile);
end

disp('Conversion completed for all files.');