%% Constants
close all
clear all
clc
Bands = {'1 Delta Band: 1Hz to 4Hz' '2 Theta Band: 4Hz to 8Hz' '3 Alpha Band: 8Hz to 13Hz' '4 Beta Band: 13Hz to 30Hz' '5 Gamma1 Band: 30Hz to 45Hz'}; % The frequency bands used

num_bins = 10; % Number of bins for the histogram
alpha = 0.01; % Significance level (p < alpha) for the ttest
OverlapTh = 0.6; % Overlap threshod (at least 100*OverlapTH% of the subjects have connections)
CthInd = 8; % Coherence threshold ((CthInd-1)/num_bins) (eg. 4 indicates Coherence above 0.3)

%% Scouts and Connections
n = 68; % Number of scouts
Nc = 2346;% brain scout interconnections

matrix = zeros(n);
count = 1;
for i = 1:n
    for j = 1:i
        matrix(j, i) = count;
        count = count + 1;
    end
end

region_mapping = {
    'bankssts L',...
    'bankssts R',...
    'caudalanteriorcingulate L',...
    'caudalanteriorcingulate R',...
    'caudalmiddlefrontal L',...
    'caudalmiddlefrontal R',...
    'cuneus L',...
    'cuneus R',...
    'entorhinal L',...
    'entorhinal R',...
    'frontalpole L',...
    'frontalpole R',...
    'fusiform L',...
    'fusiform R',...
    'inferiorparietal L',...
    'inferiorparietal R',...
    'inferiortemporal L',...
    'inferiortemporal R',...
    'insula L',...
    'insula R',...
    'isthmuscingulate L',...
    'isthmuscingulate R',...
    'lateraloccipital L',...
    'lateraloccipital R',...
    'lateralorbitofrontal L',...
    'lateralorbitofrontal R',...
    'lingual L',...
    'lingual R',...
    'medialorbitofrontal L',...
    'medialorbitofrontal R',...
    'middletemporal L',...
    'middletemporal R',...
    'paracentral L',...
    'paracentral R',...
    'parahippocampal L',...
    'parahippocampal R',...
    'parsopercularis L',...
    'parsopercularis R',...
    'parsorbitalis L',...
    'parsorbitalis R',...
    'parstriangularis L',...
    'parstriangularis R',...
    'pericalcarine L',...
    'pericalcarine R',...
    'postcentral L',...
    'postcentral R',...
    'posteriorcingulate L',...
    'posteriorcingulate R',...
    'precentral L',...
    'precentral R',...
    'precuneus L',...
    'precuneus R',...
    'rostralanteriorcingulate L',...
    'rostralanteriorcingulate R',...
    'rostralmiddlefrontal L',...
    'rostralmiddlefrontal R',...
    'superiorfrontal L',...
    'superiorfrontal R',...
    'superiorparietal L',...
    'superiorparietal R',...
    'superiortemporal L',...
    'superiortemporal R',...
    'supramarginal L',...
    'supramarginal R',...
    'temporalpole L',...
    'temporalpole R',...
    'transversetemporal L',...
    'transversetemporal R'...
    };

region_map = containers.Map(region_mapping, 1:length(region_mapping));



%% Define Connections
coordinates = zeros(Nc, 2);
for m = 1:Nc
    [row, col] = find(matrix == m);
    coordinates(m, :) = [row, col];
end
selfConnections = find((coordinates(:,1)-coordinates(:,2))==0);
nonselfConnections = findAnotinB(1:Nc,selfConnections);
region_names = cell(size(coordinates, 1), size(coordinates, 2));

for i = 1:size(coordinates, 1)
    for j = 1:size(coordinates, 2)
        region_names{i, j} = region_mapping{coordinates(i, j)};
    end
end
Connections = {Nc}; % The list of all the possible connections between brain regions
for i = 1:size(coordinates, 1)
    Connections{i} = sprintf([ num2str(i) '-(' num2str(coordinates(i, 1)) ') ' region_names{i, 1} ' - (' num2str(coordinates(i, 2)) ') ' region_names{i, 2}]);
end



%% Load Data
load Coherence

% Remove self connections
% Coherence.AZ(selfConnections)=nan;
% Coherence.HC(selfConnections)=nan;
% Coherence.FTD(selfConnections)=nan;
% Connections with a coherence value above a given threshold is choosen as
% connected with the connection strenth of coherence


% Define percentages for training and testing
trainPercentage = 0.7;
testPercentage = 0.3;

% Number of random splits
numSplits = 100;

% Loop for creating 100 datasets
for dataset = 1:numSplits
    % Initialize dataset-specific structures
    Dataset(dataset).AZ_TR = [];
    Dataset(dataset).AZ_TR_IN = [];
    Dataset(dataset).AZ_TE = [];
    Dataset(dataset).AZ_TE_IN = [];
    
    Dataset(dataset).FTD_TR = [];
    Dataset(dataset).FTD_TR_IN = [];
    Dataset(dataset).FTD_TE = [];
    Dataset(dataset).FTD_TE_IN = [];
    
    Dataset(dataset).HC_TR = [];
    Dataset(dataset).HC_TR_IN = [];
    Dataset(dataset).HC_TE = [];
    Dataset(dataset).HC_TE_IN = [];
    
    % Get the total number of patients for each type
    numAZ = size(Coherence.AZ, 3);
    numFTD = size(Coherence.FTD, 3);
    numHC = size(Coherence.HC, 3);
    
    % Calculate the number of patients for training and testing
    numTrainAZ = floor(trainPercentage * numAZ);
    numTrainFTD = floor(trainPercentage * numFTD);
    numTrainHC = floor(trainPercentage * numHC);
    
    % Randomly select patients for training
    indicesAZ = randperm(numAZ, numTrainAZ);
    indicesFTD = randperm(numFTD, numTrainFTD);
    indicesHC = randperm(numHC, numTrainHC);
    
    % Save indices for training and testing
    Dataset(dataset).AZ_TR_IN = indicesAZ;
    Dataset(dataset).AZ_TE_IN = setdiff(1:numAZ, indicesAZ);
    
    Dataset(dataset).FTD_TR_IN = indicesFTD;
    Dataset(dataset).FTD_TE_IN = setdiff(1:numFTD, indicesFTD);
    
    Dataset(dataset).HC_TR_IN = indicesHC;
    Dataset(dataset).HC_TE_IN = setdiff(1:numHC, indicesHC);
    
    % Split data for each type of patient
    Dataset(dataset).AZ_TR = Coherence.AZ(:, :, indicesAZ);
    Dataset(dataset).AZ_TE = Coherence.AZ(:, :, Dataset(dataset).AZ_TE_IN);
    
    Dataset(dataset).FTD_TR = Coherence.FTD(:, :, indicesFTD);
    Dataset(dataset).FTD_TE = Coherence.FTD(:, :, Dataset(dataset).FTD_TE_IN);
    
    Dataset(dataset).HC_TR = Coherence.HC(:, :, indicesHC);
    Dataset(dataset).HC_TE = Coherence.HC(:, :, Dataset(dataset).HC_TE_IN);
    
    % Calculate mean and standard error for each group in the training set
    Dataset(dataset).AZ_mean = mean(Dataset(dataset).AZ_TR, 3);
    Dataset(dataset).FTD_mean = mean(Dataset(dataset).FTD_TR, 3);
    Dataset(dataset).HC_mean = mean(Dataset(dataset).HC_TR, 3);
    
    Dataset(dataset).AZ_ste = std(Dataset(dataset).AZ_TR, 0, 3) / sqrt(numTrainAZ);
    Dataset(dataset).FTD_ste = std(Dataset(dataset).FTD_TR, 0, 3) / sqrt(numTrainFTD);
    Dataset(dataset).HC_ste = std(Dataset(dataset).HC_TR, 0, 3) / sqrt(numTrainHC);
end

% Save the datasets to a file
save('Datasets.mat', 'Dataset');

% Looping through the training Data sets and Testing whether the the
% choosed connections can be used to differenciate the categories 


% For saving the data obtained from training data set 
Resultset = struct();  % Initialize Resultset array

for j =  1:100 


    for i = 1:num_bins
        Cthreshold = (i-1)/num_bins;
        Connected.AZ(:,:,:,i) = Dataset(j).AZ_TR > Cthreshold;
        Connected.HC (:,:,:,i)= Dataset(j).HC_TR > Cthreshold;
        Connected.FTD (:,:,:,i)= Dataset(j).FTD_TR > Cthreshold;
    
    end
    % The fraction of poppulation showing the connections
    FracConnected.AZ = squeeze(sum(Connected.AZ,3)/25);
    FracConnected.HC = squeeze(sum(Connected.HC,3)/20);
    FracConnected.FTD = squeeze(sum(Connected.FTD,3)/16);
    
    
    %% t-test
    Kall = [];
    % allk=[];
    for band = 1:5
        %%
        KKK = 1:Nc;
        
        X = (squeeze(FracConnected.AZ(KKK,band,:)));
        Y = (squeeze(FracConnected.HC(KKK,band,:)));
        Z = (squeeze(FracConnected.FTD(KKK,band,:)));
        
        KK1 = unique([find(Y(:,CthInd)>OverlapTh) ;find(X(:,CthInd)>OverlapTh)]);
        KK1 =KK1(findAnotinB(KK1,selfConnections)); % remove self connections
        KK2 = unique([find(Z(:,CthInd)>OverlapTh) ;find(X(:,CthInd)>OverlapTh)]);
        KK2 =KK2(findAnotinB(KK2,selfConnections)); % remove self connections 
        KK3 = unique([find(Z(:,CthInd)>OverlapTh) ;find(Y(:,CthInd)>OverlapTh)]);
        KK3 = KK3(findAnotinB(KK3,selfConnections)); % remove self connections
    
        KK= unique([KK1;KK2;KK3]);
    
        [H1, P1, ~, st1]  = ttest2(squeeze(Dataset(j).FTD_TR(KKK,band,:))',squeeze(Dataset(j).HC_TR(KKK,band,:))','alpha',alpha);
        [H2, P2, ~, st2]  = ttest2(squeeze(Dataset(j).AZ_TR(KKK,band,:))',squeeze(Dataset(j).HC_TR(KKK,band,:))','alpha',alpha);
        [H3, P3, ~, st3]  = ttest2(squeeze(Dataset(j).AZ_TR(KKK,band,:))',squeeze(Dataset(j).FTD_TR(KKK,band,:))','alpha',alpha);
        
        % Select only the connections that show significant difference (H=1),
        % that satisfy the overlap and thresholding criteria (connections in the KK list)
        K1 = KK(findAinB(KKK(H1==1),KK)); % FTD vs HC [ 2 vs 1]
        K2 = KK(findAinB(KKK(H2==1),KK)); % AZ vs HC [3 vs 1]
        K3 = KK(findAinB(KKK(H3==1),KK)); % AZ vs FTD [3 vs 2]
        K = unique([K1;K2;K3]);
    
        %%
        k.k1=  findAinB(K1,K);
        k.k2 = findAinB(K2,K);
        k.k3 = findAinB(K3,K);
        k.k = unique([k.k1 k.k2 k.k3]);
        k.p1 = P1(K(k.k1)); % FTD vs HC
        k.p2 = P2(K(k.k2)); % AZ vs HC
        k.p3 = P3(K(k.k3)); % AZ vs FTD
        k.K = K;
        k.st1 = st1;
        k.st2 = st2;
        k.st3 = st3;
        k.alpha = alpha;
        allk(band) = k;

        % saving into results set  

        Resultset(j).k.k1 = k.k1;
        Resultset(j).k.k2 = k.k2;
        Resultset(j).k.k3 = k.k3;
        Resultset(j).k.k = k.k;
        Resultset(j).k.p1 = k.p1;
        Resultset(j).k.p2 = k.p2;
        Resultset(j).k.p3 = k.p3;
        Resultset(j).k.K = k.K;
        Resultset(j).k.st1 = k.st1;
        Resultset(j).k.st2 = k.st2;
        Resultset(j).k.st3 = k.st3;
        Resultset(j).k.alpha = k.alpha;
        Resultset(j).allk = allk;


    end
end

save('Resultsets.mat', 'Resultset');

%     % Add connection text to the plot
%     for i=1:length(K)
%         t=text(i,0,Connections(KKK(K(i))));
%         t.Rotation = -90;
%     end
%     title(['Candidate Biomarker Brain Connections for' Bands(band)])
%     ylabel('Coherence')
%     legend({'NC' 'FD' 'AZ' })
%     set(gca,'XTickLabel',{})
%     ax = gca;
%     set(gca,'YLim', [0 1])
%     drawnow
%     
%     figure(6)
%     subplot(5,2,band*2-1)
%     hold on
%     plot(squeeze(FracConnected.HC(K,band,CthInd)),'ob-','linewidth',2)
%     plot(squeeze(FracConnected.FTD(K,band,CthInd)),'+r--','linewidth',2)
%     plot(squeeze(FracConnected.AZ(K,band,CthInd)),'*g:','linewidth',2)
%     title(Bands{band})
%     
%     % suptitle('Overlap fraction between subjects for the selected connections')
%     
%     for i=1:length(K)
%         t=text(i,0,num2str(K(i)));
%         t.Rotation = -90;
%     end
%     if band ==3
%         ylabel('Fractional Overlap between Subjects')
%         legend({'NC' 'FD' 'AZ' })
%     end
%     set(gca,'XTickLabel',{})
%     set(gca,'YLim', [0 1])
%     
%     Kall = [Kall;allk(band).K];
% 
% 
% 
% 
% 
% end
% %%
% figure(6)
% % subplot(2,3,6)
% 
% Kall = unique(Kall);
% 
% for i=1:length(Kall)
%     t=text(3.5,8-(i/5),Connections(KKK(Kall(i))));
%     
%     t.Rotation = 0;
% end
% 
% %%
% [SC, I] = sort(Coherence.mean,1);
% Col = [1 0 0 ; 0 1 0; 0 0 1];
% Col2 = Col*0.8;
% figure;
% for band = 1:5
%     subplot(3,2,band)
%     for cond = 1:3;
%         i=(cond-1)*5+band;
%         p=fill([1:Nc Nc:-1:1],[squeeze(Coherence.mean(I(:,band,1),band,cond))+squeeze(Coherence.ste(I(:,band,1),band,cond));squeeze(Coherence.mean(I(Nc:-1:1,band,1),band,cond))-squeeze(Coherence.ste(I(Nc:-1:1,band,1),band,cond))],Col(cond,:));
%         p.FaceColor = Col2(cond,:);
%         p.EdgeColor = 'none';
%         p.FaceAlpha = 0.5;  
%         hold on;
%         plot(1:Nc,squeeze(Coherence.mean(I(:,band,1),band,cond)),'color',Col(cond,:),'linewidth',1);
%         title(Bands{band})
%         set(get(get(p(:),'Annotation'),'LegendInformation'),'IconDisplayStyle','off'); 
%         ylabel('Coherence')
%         xlabel('HC Ranked connection')
%        
%     end;
% end
% legend({'HC' 'FTD' 'AZ'})