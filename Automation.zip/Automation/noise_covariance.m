%% ================================================================
%  Add Noise Covariance (No noise modeling) to an existing head model
% ================================================================

ProtocolName = 'Coherence_PLV';
SubjectName  = 'NewSubject';

% Path to your preprocessed data file
DataFile = 'H:\brainstorm_db\Coherence_PLV\data\NewSubject\@rawsub-001_task-eyesclosed_eeg_band_notch\data_0raw_sub-001_task-eyesclosed_eeg_band_notch.mat';

%% 1) Init Brainstorm (no GUI)
if ~brainstorm('status')
    brainstorm nogui
end

%% 2) Set protocol
iProtocol = bst_get('Protocol', ProtocolName);
if isempty(iProtocol)
    error(['Protocol "', ProtocolName, '" not found.']);
end
gui_brainstorm('SetCurrentProtocol', iProtocol);

%% 3) Load the data file
sFiles = {DataFile};

%% 4) Add Noise Covariance: No noise modeling
bst_process('CallProcess', 'process_noisecov', sFiles, [], ...
    'baseline',    [], ...       % [] = full file (ignored if no noise modeling)
    'dcoffset',    1, ...
    'datapower',   0, ...
    'sensortypes', 'EEG', ...
    'target',      1, ...        % Noise covariance for source reconstruction
    'overwrite',   1, ...
    'method',      1);           % 1 = No noise modeling

disp('==== Noise covariance (No noise modeling) added successfully ====');
