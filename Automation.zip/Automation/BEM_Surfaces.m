%% ================================================================
%  Generate BEM surfaces (OpenMEEG) with ~1082 vertices each
% ================================================================

ProtocolName = 'Coherence_PLV';
SubjectName  = 'NewSubject';

%% 1) Init Brainstorm (no GUI)
if ~brainstorm('status')
    brainstorm nogui
end

%% 2) Set protocol
iProtocol = bst_get('Protocol', ProtocolName);
if isempty(iProtocol)
    error(['Protocol "', ProtocolName, '" not found.']);
end
gui_brainstorm('SetCurrentProtocol', iProtocol);

%% 3) Get subject
sSubject = bst_get('Subject', SubjectName);
if isempty(sSubject)
    error(['Subject "', SubjectName, '" not found.']);
end

%% 4) Generate BEM surfaces (OpenMEEG)
bst_process('CallProcess', 'process_generate_bem', [], [], ...
    'subjectname', SubjectName, ...
    'bemtype',     'openmeeg');

%% 5) Resample meshes (Scalp, Skull, Brain) to 1082 vertices
% Loop through the three BEM meshes and resample each
for iSurf = 1:3
    bst_process('CallProcess', 'process_resample', [], [], ...
        'nvertices', 1082, ...       % target vertices
        'method',    'reduce', ...   % reduce (decimation)
        'target',    iSurf, ...      % 1=Scalp, 2=OuterSkull, 3=InnerSkull
        'subjectname', SubjectName);
end

disp('==== BEM surfaces generated and resampled to 1082 vertices each ====');
